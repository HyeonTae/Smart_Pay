package com.example.actiontogether;

public class Customer {
	private String Cid;
	private String Cpass;
	private String Cname;
	private String Ccash;
	public Customer(String cid, String cpass, String cname, String ccash) {
		super();
		Cid = cid;
		Cpass = cpass;
		Cname = cname;
		Ccash = ccash;
	}
	public String getCid() {
		return Cid;
	}
	public void setCid(String cid) {
		Cid = cid;
	}
	public String getCpass() {
		return Cpass;
	}
	public void setCpass(String cpass) {
		Cpass = cpass;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getCcash() {
		return Ccash;
	}
	public void setCcash(String ccash) {
		Ccash = ccash;
	}
	@Override
	public String toString() {
		return "Customer [Cid=" + Cid + ", Cpass=" + Cpass + ", Cname=" + Cname + ", Ccash=" + Ccash + "]";
	}
	
}
