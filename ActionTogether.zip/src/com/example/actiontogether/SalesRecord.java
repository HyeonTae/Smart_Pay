package com.example.actiontogether;

public class SalesRecord {
	private String date;
	private String value;
	
	public SalesRecord(String date, String value) {
		super();
		this.date = date;
		this.value = value;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "SalesRecord [date=" + date + ", value=" + value + "]";
	}
	
	
}
