package com.example.actiontogether;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;

public class LoginActivity extends Activity {
	
	Button btn;
	RadioButton cradio,mradio;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
	
		cradio = (RadioButton) findViewById(R.id.Cradio);
		mradio = (RadioButton) findViewById(R.id.Mradio);
		
		
		findViewById(R.id.loginBtn).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(cradio.isChecked()){
					Intent i1 = new Intent(LoginActivity.this,CustomerActivity.class);
					startActivity(i1);
				}
				if(mradio.isChecked()){
					Intent i2 = new Intent(LoginActivity.this,MerchantActivity.class);
					startActivity(i2);
				}
			}
		});
	}
}
