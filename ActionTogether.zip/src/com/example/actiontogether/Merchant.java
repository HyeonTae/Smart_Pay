package com.example.actiontogether;

public class Merchant {
	private String Mid;
	private String Mpass;
	private String Mname;
	private String Mcash;
	
	public Merchant(String mid, String mpass, String mname, String mcash) {
		super();
		Mid = mid;
		Mpass = mpass;
		Mname = mname;
		Mcash = mcash;
	}

	public String getMid() {
		return Mid;
	}

	public void setMid(String mid) {
		Mid = mid;
	}

	public String getMpass() {
		return Mpass;
	}

	public void setMpass(String mpass) {
		Mpass = mpass;
	}

	public String getMname() {
		return Mname;
	}

	public void setMname(String mname) {
		Mname = mname;
	}

	public String getMcash() {
		return Mcash;
	}

	public void setMcash(String mcash) {
		Mcash = mcash;
	}

	@Override
	public String toString() {
		return "Merchant [Mid=" + Mid + ", Mpass=" + Mpass + ", Mname=" + Mname + ", Mcash=" + Mcash + "]";
	}
	
	
	
	
	
}
